import os, zipfile, urllib.request
import xbmc, xbmcgui, xbmcvfs

URL = 'https://drive.usercontent.google.com/download?id=1cjwN7cclveX2hHhhvKtl9Qqdn-ZPW7gL&export=download&confirm=t'
HOME = xbmcvfs.translatePath('special://home/')
TMP = os.path.join(xbmcvfs.translatePath('special://temp/'), 'kaleido-fullbuild.zip')

dlg = xbmcgui.Dialog()
if not dlg.yesno('KALEIDO', 'Install the full KALEIDO build now?[CR]Downloads about 230 MB, installs everything, and sets KALEIDO as your skin.'):
    raise SystemExit

dp = xbmcgui.DialogProgress()
dp.create('KALEIDO', 'Downloading build...')
def hook(blocks, bs, total):
    if total > 0:
        dp.update(min(100, int(blocks * bs * 100 / total)), 'Downloading build...')
try:
    urllib.request.urlretrieve(URL, TMP, hook)
except Exception as e:
    dp.close()
    dlg.ok('KALEIDO', 'Download failed: %s' % e)
    raise SystemExit

dp.update(0, 'Installing files...')
try:
    z = zipfile.ZipFile(TMP)
    names = z.namelist()
    for i, name in enumerate(names):
        z.extract(name, HOME)
        if i % 40 == 0:
            dp.update(int(i * 100 / max(1, len(names))), 'Installing files...')
    z.close()
except Exception as e:
    dp.close()
    dlg.ok('KALEIDO', 'Install failed: %s' % e)
    raise SystemExit
dp.close()
try:
    os.remove(TMP)
except Exception:
    pass
dlg.ok('KALEIDO', 'Build installed. Press OK and Kodi will close.[CR]Reopen Kodi - KALEIDO will be your skin.')
os._exit(0)
